
package principal;


public class Principal {

   
    public static void main(String[] args) {

//clinica medica que registra asistencias medica y los pagos de sus afiñiados

    }
    
}
