
package principal;


public class Administrativos extends Empleados{
    
}
