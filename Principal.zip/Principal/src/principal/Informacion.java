
package principal;


public class Informacion {
    
}
