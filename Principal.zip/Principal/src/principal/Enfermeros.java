
package principal;


public class Enfermeros  extends Empleados{
    
}
