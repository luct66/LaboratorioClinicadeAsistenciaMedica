
package principal;


public class AsistenciaMedica{ //Esta clase reune las condiciones´para la asistencia medica
                                //Doctor Enfermero Chofer Movil 
    
                             
    // Tal vez aqui vaya a estra tambien el metodo que indique el tipo de asistencia que
    //recibio y el diagnostico del doctor que lo atendio
    //Y la informacion que de cada asistencia 
    
    public void RegistrarAsistencia(){
        //Tipo de Diagnostico
    }
    public void RegistrarDiagnostico(){
        
    }

    
}
