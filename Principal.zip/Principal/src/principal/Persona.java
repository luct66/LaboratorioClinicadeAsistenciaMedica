
package principal;

public class Persona {
public String Nombre;
public String Direccion;
public String Fechadenacimiento;
public String Documento;
public String Telefono;
public String DireccionCorreo;
                        
                        
                        





}
