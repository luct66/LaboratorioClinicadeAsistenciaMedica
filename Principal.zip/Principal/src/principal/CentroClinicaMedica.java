
package principal;


public class CentroClinicaMedica {
    
}
