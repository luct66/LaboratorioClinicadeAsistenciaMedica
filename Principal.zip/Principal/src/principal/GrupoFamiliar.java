
package principal;


public class GrupoFamiliar extends Afiliados{
    
    
    
    
    
}
