
package principal;


public class Afiliados extends Persona{
    
}
