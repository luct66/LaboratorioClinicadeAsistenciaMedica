
package principal;


public class Solicitud {
    
    public void registrarsolicitud(){

}
    
}
