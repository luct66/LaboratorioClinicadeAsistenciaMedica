
package principal;

public class Pago { //Aca se va registrar el pago por abono para los afiliados 
                        //una tarifa por doctor y por grupo familiar 
                       //que posea el afiliado
    
    
    public void registrarPago(){
        
    }
}

