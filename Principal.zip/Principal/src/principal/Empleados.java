
package principal;


public class Empleados extends Persona{
    
}
